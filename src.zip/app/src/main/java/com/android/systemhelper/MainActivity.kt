package com.android.systemhelper
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private val mpLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            val i = Intent(this, ScreenCaptureService::class.java)
            i.putExtra("code", res.resultCode); i.putExtra("data", res.data)
            startForegroundService(i); Toast.makeText(this, "截屏授权成功", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val et = findViewById<EditText>(R.id.etCard)
        val btnV = findViewById<Button>(R.id.btnVerify)
        val btnAcc = findViewById<Button>(R.id.btnAcc)
        val btnScreen = findViewById<Button>(R.id.btnScreen)
        btnV.setOnClickListener {
            if (Auth.verify(et.text.toString())) {
                Toast.makeText(this, "卡密正确", Toast.LENGTH_SHORT).show()
                btnAcc.isEnabled = true; btnScreen.isEnabled = true
            } else { Toast.makeText(this, "卡密错误", Toast.LENGTH_SHORT).show() }
        }
        btnAcc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnScreen.setOnClickListener {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mpLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }
}
