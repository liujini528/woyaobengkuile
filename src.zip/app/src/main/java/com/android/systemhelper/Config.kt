package com.android.systemhelper
object Config { var espEnable = true; var authed = false }
